import uvicorn
from fastapi import FastAPI
from DiabetesNote import DiabetesNote
import numpy as np
import pickle
import pandas as pd

app = FastAPI()
pickle_in = open("classifier.pkl","rb")
classifier= pickle.load(pickle_in)



@app.post("/predict")
def predict_diabetes_note(data:DiabetesNote):
    data = data.dict()
    pregnancies = data["Pregnancies"]
    glucose = data["Glucose"]
    bloodPressure = data["BloodPressure"]
    skinThickness = data["SkinThickness"]
    insulin = data["Insulin"]
    bMI = data["BMI"]
    diabetesPedigreeFunction = data["DiabetesPredigreeFunction"]
    age = data["Age"]
    outcome = data["Outcome"]
    
    prediction = classifier.predict([[pregnancies,glucose,bloodPressure,skinThickness,insulin,bMI,diabetesPedigreeFunction,age,outcome]])
    
    if(prediction[0]>0.5):
        prediction="No es diabetico"
    else:
        prediction= "Sí es diabetico" 
        
    return {"prediction":prediction}    

if __name__== "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)  
    
    
    #para correr el servidor es uvicorn app:app --reload 
        